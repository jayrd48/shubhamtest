## Prequisite

## Tested On 
- Docker version 20.10.8
- docker-compose version 1.29.2 

## Run Docker Compose UP Command to Spin Up Stack
$ docker-compose up -d
